Submitting a2.py and basic_handshake.py

a2.py is an unaltered file containing necessary functions used in basic_handshake.py

basic_handshake.py implements a toy version of the TLS handshake, main homework componenent


Finished implementing all functions but the protocols are mostly untested and are running into bugs preventing the autograder from passing. 